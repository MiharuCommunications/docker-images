module IssuesExportHelper
  def add_journals(csv)
    csv_with_journals = CSV.generate do |newcsv|
      CSV.parse(Redmine::CodesetUtil.to_utf8(csv, 'CP932'), :headers => true, :return_headers => true) do |row|
        week = 1.week.ago.beginning_of_day
        # Rails.logger.info "1週間前 #{week}"
        if row.header_row?
          newcsv << row.fields + [t(:label_history)]
        else
          comments = ""
          Issue.find(row.fields.first).journals.map do |j| 
            # Rails.logger.info "更新日時 #{j.created_on} : #{week < j.created_on}"
            if week < j.created_on
              comments << '['+ j.created_on.strftime("%Y/%m/%d %H:%M:%S")+'] ' + "\n" + j.user.name + "\n" + j.details.map {|d| show_detail(d, true)}.join("\n") + "\n" + (j.notes.nil? ? '' :     j.notes)
            end
          end
          newcsv << row.fields + [comments]
        end
      end
    end
    Redmine::CodesetUtil.from_utf8(csv_with_journals, 'CP932')
  end
end
