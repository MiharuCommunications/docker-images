Redmine Export with Journals Plugin
========================================
[![Code Climate](https://codeclimate.com/github/suer/redmine_export_with_journals.png)](https://codeclimate.com/github/suer/redmine_export_with_journals)

A redmine plugin to export issues CSV with history.

Requirements
---------------------
* Redmine 4.0.0 or later

Installation
---------------------

1. $ cd REDMINE_ROOT/plugins
2. $ git clone git://github.com/suer/redmine_export_with_journals.git
3. restart redmine
