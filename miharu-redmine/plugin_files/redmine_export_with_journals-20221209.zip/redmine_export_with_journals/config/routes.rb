get 'projects/issues_export/export_with_journals', controller: 'issues_export', action: 'export_with_journals'
