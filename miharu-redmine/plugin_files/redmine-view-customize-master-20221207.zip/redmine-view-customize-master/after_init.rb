require File.expand_path('../lib/redmine_view_customize/view_hook', __FILE__)
