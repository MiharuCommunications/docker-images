---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

## Summary


## Description


## Environment

- View customize plugin version
- Redmine version
- Ruby version
- Rails version
- Installed other plugins

You can get these informations from Redmine's information page.
(E.g. http://example.com/admin/info)
